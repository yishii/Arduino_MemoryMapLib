

cp MemoryMapLib* /Applications/Arduino.app/Contents/Resources/Java/libraries/MemoryMapLib/
cp SerialStream* /Applications/Arduino.app/Contents/Resources/Java/libraries/MemoryMapLib/
cp CommunicationStream* /Applications/Arduino.app/Contents/Resources/Java/libraries/MemoryMapLib/


cp AndroidAccessoryStream* /Applications/Arduino.app/Contents/Resources/Java/libraries/MemoryMapLib/
cp BufferedStream* /Applications/Arduino.app/Contents/Resources/Java/libraries/MemoryMapLib/
