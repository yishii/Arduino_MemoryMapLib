/*
  Communication Stream class

  Author : Yasuhiro ISHII
*/

#include "CommunicationStream.h"

int CommunicationStream::isConnected(void)
{
    return(0);
}

unsigned char CommunicationStream::read(void)
{
    return(0);
}

int CommunicationStream::write(unsigned char* buff,int len)
{
    return(0);
}

int CommunicationStream::available(void)
{
    return(0);
}

void CommunicationStream::flush(void)
{

}
